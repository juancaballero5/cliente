// ============================
// 📄 routes/accesoDB/mysql/index.js
// ============================
"use strict";

const express = require("express");
const router = express.Router();

// Importar rutas individuales
const grabar = require("../grabar");
const leer = require("../leer");
const borrar = require("../borrar");
const sesion = require("../sesion");

// Asociar rutas activas
router.use("/", grabar);
router.use("/", leer);
router.use("/", borrar);
router.use("/sesion", sesion);

module.exports = router;
